import LaboratoryPage from "@/app/(tools)/components/PageComponents/laboratory/LaboratoryPage";
import React from "react";
type Props = {};
function Laboratorium(params: Props) {
  return <LaboratoryPage />;
}

export default Laboratorium;
