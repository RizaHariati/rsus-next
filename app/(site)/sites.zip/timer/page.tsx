import TimerComponent from "@/app/(tools)/components/PageComponents/TimerComponent";
type Props = {};

const Timer = (props: Props) => {
  return <TimerComponent />;
};

export default Timer;
