import PatientRightPage from "@/app/(tools)/components/PageComponents/PatientRightPage";
import React from "react";

type Props = {};

function PatientRight(params: Props) {
  return <PatientRightPage />;
}
export default PatientRight;
