import PoliklinikPage from "@/app/(tools)/components/PageComponents/poliklinik/PoliklinikPage";
import React from "react";
type Props = {};
function Poliklinik(params: Props) {
  return <PoliklinikPage />;
}
export default Poliklinik;
