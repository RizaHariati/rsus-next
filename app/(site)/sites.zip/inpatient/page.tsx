import React from "react";
import InpatientPage from "@/app/(tools)/components/PageComponents/inpatient/InpatientPage";

type Props = {};

function InPatient(params: Props) {
  return <InpatientPage />;
}

export default InPatient;
