import React from "react";

import AboutGroupPage from "@/app/(tools)/components/PageComponents/about/AboutGroupPage";

type Props = {};

function AboutGroup(params: Props) {
  return <AboutGroupPage />;
}
export default AboutGroup;
