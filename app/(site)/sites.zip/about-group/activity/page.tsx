import ActivityPage from "@/app/(tools)/components/PageComponents/about/ActivityPage";
import React from "react";

type Props = {};
export default function Activity(props: Props) {
  return <ActivityPage />;
}
