import React from "react";

import TeamPage from "@/app/(tools)/components/PageComponents/about/TeamPage";

type Props = {};

function Team(params: Props) {
  return <TeamPage />;
}
export default Team;
